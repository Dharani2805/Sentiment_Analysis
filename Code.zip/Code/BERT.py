import torch
from transformers import BertTokenizer, BertForSequenceClassification, AdamW
from torch.utils.data import DataLoader, TensorDataset
from sklearn.model_selection import train_test_split
import pandas as pd
from sklearn.preprocessing import LabelEncoder
import matplotlib.pyplot as plt

class SentimentClassifier:
    def __init__(self, model_name='bert-base-uncased', batch_size=32, learning_rate=1e-5, epochs=10):
        self.model_name = model_name
        self.batch_size = batch_size
        self.learning_rate = learning_rate
        self.epochs = epochs
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
         # Load tokenizer and model
        self.tokenizer = BertTokenizer.from_pretrained(self.model_name, do_lower_case=True)
        num_labels = len(df['sentiment'].unique())  # Update num_labels dynamically
        self.model = BertForSequenceClassification.from_pretrained(
            self.model_name,
            num_labels=num_labels,
            output_attentions=False,
            output_hidden_states=False,
        ).to(self.device)
        
        # Optimizer and loss function
        self.optimizer = AdamW(self.model.parameters(), lr=self.learning_rate)
        self.criterion = torch.nn.CrossEntropyLoss()
        
        # Data loaders
        self.train_loader, self.valid_loader, self.test_loader = self._prepare_data()
        
        # Training history
        self.train_loss_values, self.train_acc_values = [], []
        self.valid_loss_values, self.valid_acc_values = [], []

    def _prepare_data(self):
        # Load data
        df['text'].fillna('[UNK]', inplace=True)
        label_encoder = LabelEncoder()
        df['sentiment'] = label_encoder.fit_transform(df['sentiment'])

        # Split into train, validation, and test datasets
        train, temp = train_test_split(df, test_size=0.2, random_state=42)
        valid, test = train_test_split(temp, test_size=0.5, random_state=42)

        # Encode data
        train_encoded = self._encode_data(train)
        valid_encoded = self._encode_data(valid)
        test_encoded = self._encode_data(test)

        # Create data loaders
        train_loader = DataLoader(train_encoded, batch_size=self.batch_size, shuffle=True)
        valid_loader = DataLoader(valid_encoded, batch_size=self.batch_size, shuffle=True)
        test_loader = DataLoader(test_encoded, batch_size=self.batch_size, shuffle=True)

        return train_loader, valid_loader, test_loader

    def _encode_data(self, data):
        encoded = self.tokenizer.batch_encode_plus(data['text'].tolist(), padding=True, truncation=True, return_tensors='pt')
        labels = torch.tensor(data['sentiment'].tolist())
        return TensorDataset(encoded['input_ids'], encoded['attention_mask'], labels)

    def train(self):
        for epoch in range(self.epochs):
            self.model.train()
            total_loss, correct, total = 0, 0, 0

            for batch in self.train_loader:
                self.optimizer.zero_grad()
                input_ids, attention_mask, labels = tuple(t.to(self.device) for t in batch)
                outputs = self.model(input_ids, token_type_ids=None, attention_mask=attention_mask, labels=labels)
                loss = outputs.loss
                total_loss += loss.item()
                _, predicted = torch.max(outputs.logits, 1)
                total += labels.size(0)
                correct += (predicted.cpu() == labels.cpu()).sum().item()
                loss.backward()
                self.optimizer.step()

            avg_train_loss = total_loss / len(self.train_loader)
            train_acc = 100 * correct / total
            print(f'Epoch: {epoch}, Training Loss: {avg_train_loss}, Training Accuracy: {train_acc}')
            self.train_loss_values.append(avg_train_loss)
            self.train_acc_values.append(train_acc)

            # Validation
            self.model.eval()
            total_loss, correct, total = 0, 0, 0

            for batch in self.valid_loader:
                input_ids, attention_mask, labels = tuple(t.to(self.device) for t in batch)
                with torch.no_grad():
                    outputs = self.model(input_ids, token_type_ids=None, attention_mask=attention_mask, labels=labels)
                    loss = outputs.loss
                    total_loss += loss.item()
                    _, predicted = torch.max(outputs.logits, 1)
                    total += labels.size(0)
                    correct += (predicted.cpu() == labels.cpu()).sum().item()

            avg_valid_loss = total_loss / len(self.valid_loader)
            valid_acc = 100 * correct / total
            print(f'Epoch: {epoch}, Validation Loss: {avg_valid_loss}, Validation Accuracy: {valid_acc}')
            self.valid_loss_values.append(avg_valid_loss)
            self.valid_acc_values.append(valid_acc)

    def test(self):
        self.model.eval()
        total, correct = 0, 0

        for batch in self.test_loader:
            input_ids, attention_mask, labels = tuple(t.to(self.device) for t in batch)
            with torch.no_grad():
                outputs = self.model(input_ids, token_type_ids=None, attention_mask=attention_mask)
                _, predicted = torch.max(outputs.logits, 1)
                total += labels.size(0)
                correct += (predicted.cpu() == labels.cpu()).sum().item()

        test_acc = 100 * correct / total
        print(f'Test Accuracy: {test_acc}')

    def plot_history(self):
        plt.plot(self.train_loss_values, 'b', label='Training loss')
        plt.plot(self.valid_loss_values, 'r', label='Validation loss')
        plt.title('Training and Validation Loss')
        plt.xlabel('Epochs')
        plt.ylabel('Loss')
        plt.legend()
        plt.show()

        plt.plot(self.train_acc_values, 'b', label='Training Acc')
        plt.plot(self.valid_acc_values, 'r', label='Validation Acc')
        plt.title('Training and Validation Accuracy')
        plt.xlabel('Epochs')
        plt.ylabel('Accuracy')
        plt.legend()
        plt.show()

# Usage
csv_file_path = '/Users/murthygabbiti/Downloads/298A project/train_simple.csv'
df = pd.read_csv(csv_file_path)

# Create an instance of SentimentClassifier
classifier = SentimentClassifier(model_name='bert-base-uncased', batch_size=32, learning_rate=1e-5, epochs=10)

# Train the model
classifier.train()

# Test the model
classifier.test()

# Plot training history
classifier.plot_history()