
from gensim.models import Word2Vec

class Word2VecTrainer:
    def __init__(self, df, sentences, vector_size=100, window=5, min_count=1, workers=4):
        self.sentences = sentences
        self.vector_size = vector_size
        self.window = window
        self.min_count = min_count
        self.workers = workers
        self.df = df

    def train_word2vec_model(self):
        return Word2Vec(self.sentences, vector_size=self.vector_size, window=self.window, min_count=self.min_count, workers=self.workers)
