import pandas as pd
from Preprocess import Preprocess
from SequencePadder import SequencePadder
from Word2VecTrainer import Word2VecTrainer
from EmbeddingMatrixCreator import EmbeddingMatrixCreator
from TextCleaner import TextCleaner
from TextDataset import TextDataset
from RNNClassifier import RNNClassifier
from LSTM import LSTMClassifier
from GRUClassifierVar import GRUClassifierVar
from GRUClassifier import GRUClassifier
from BiLSTMClassifier import BiLSTMClassifier
from TrainAndEvaluate import TrainAndEvaluate
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from torch.utils.data import DataLoader, Dataset
import torch.nn as nn
import torch.optim as optim
import torch

class Main:
    def __init__(self):
        self.df = None
        self.preprocess = None
        self.word2VecTrainer = None
        self.textCleaner = None
        self.vocab = None
        self.padsequences = None
        self.word2VecOut = None
        self.embeddingMatrix = None
        self.train_dataset = None
        self.test_dataset = None
        self.valid_dataset = None
        self.label_encoder = None
        
    def run(self):
        self.df = pd.read_csv('deeplearning/project/train_simple.csv')
        self.preprocess = Preprocess(self.df)
        
        self.textCleaner = TextCleaner(self.df)
        self.df = self.preprocess.prepare()
        self.df = self.textCleaner.clean_dataframe_columns('text', 'text_clean')
        self.df = self.textCleaner.clean_dataframe_columns('prompt', 'prompt_clean')
        sentences = [row.split() for row in self.df['text_clean']]
        self.word2VecTrainer = Word2VecTrainer(self.df, sentences=sentences)
        self.label_encoder, self.df = self.preprocess.labelEncoding()
        self.preprocess.tokenize()
        self.vocab = self.preprocess.buildVocabulary()
        
        ## Transformation
        
        self.word2VecOut = self.word2VecTrainer.train_word2vec_model()
        ## Embedding Matrix
        word_index = {'the': 1, 'and': 2, 'to': 3}
        embeddingMatrixCreator = EmbeddingMatrixCreator(word_index, self.word2VecOut)
        self.embeddingMatrix = embeddingMatrixCreator.create_embedding_matrix()

        ## Load datasets
        train_df, remaining_df = train_test_split(self.df, stratify=self.df['label'], test_size=0.3, random_state=42)
        valid_df, test_df = train_test_split(remaining_df, stratify=remaining_df['label'], test_size=0.5, random_state=42)

        train_dataset = TextDataset(train_df, self.vocab, self.label_encoder)
        valid_dataset = TextDataset(valid_df, self.vocab, self.label_encoder)
        test_dataset = TextDataset(test_df, self.vocab, self.label_encoder)
        
        # DataLoaders with improved efficiency
        train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True, collate_fn=self.preprocess.collate_batch, num_workers=4, pin_memory=True)
        valid_loader = DataLoader(valid_dataset, batch_size=64, collate_fn=self.preprocess.collate_batch, num_workers=4, pin_memory=True)
        test_loader = DataLoader(test_dataset, batch_size=64, collate_fn=self.preprocess.collate_batch, num_workers=4, pin_memory=True)

        # Model
        model = RNNClassifier(len(self.vocab), self.vocab, len(self.label_encoder.classes_))
        criterion = nn.CrossEntropyLoss()
        optimizer = optim.AdamW(model.parameters(), lr=1e-3)
        train = TrainAndEvaluate(model, train_loader, test_loader, optimizer, criterion, 1)
        train.train_model(model, train_loader, optimizer, criterion)
        train.evaluate_model(model, valid_loader, criterion)
        train_losses, valid_losses, train_accuracies, valid_accuracies = train.calculateLossesAndAccuracies(model, train_loader, valid_loader, optimizer, criterion, 2)
        train.plot_loss(train_losses, valid_losses, train_accuracies, valid_accuracies)
        

        # Model
        model = LSTMClassifier(len(self.vocab), self.vocab, len(self.label_encoder.classes_))
        criterion = nn.CrossEntropyLoss()
        optimizer = optim.AdamW(model.parameters(), lr=1e-3)
        train = TrainAndEvaluate(model, train_loader, test_loader, optimizer, criterion, 1)
        train.train_model(model, train_loader, optimizer, criterion)
        train.evaluate_model(model, valid_loader, criterion)
        train_losses, valid_losses, train_accuracies, valid_accuracies = train.calculateLossesAndAccuracies(model, train_loader, valid_loader, optimizer, criterion, 2)
        train.plot_loss(train_losses, valid_losses, train_accuracies, valid_accuracies)
        
        # Model
        model = BiLSTMClassifier(len(self.vocab), self.vocab, len(self.label_encoder.classes_))
        criterion = nn.CrossEntropyLoss()
        optimizer = optim.AdamW(model.parameters(), lr=1e-3)
        train = TrainAndEvaluate(model, train_loader, test_loader, optimizer, criterion, 1)
        train.train_model(model, train_loader, optimizer, criterion)
        train.evaluate_model(model, valid_loader, criterion)
        train_losses, valid_losses, train_accuracies, valid_accuracies = train.calculateLossesAndAccuracies(model, train_loader, valid_loader, optimizer, criterion, 2)
        train.plot_loss(train_losses, valid_losses, train_accuracies, valid_accuracies)
        
        # Model
        model = GRUClassifier(len(self.vocab), self.vocab, len(self.label_encoder.classes_))
        criterion = nn.CrossEntropyLoss()
        optimizer = optim.AdamW(model.parameters(), lr=1e-3)
        train = TrainAndEvaluate(model, train_loader, test_loader, optimizer, criterion, 1)
        train.train_model(model, train_loader, optimizer, criterion)
        train.evaluate_model(model, valid_loader, criterion)
        train_losses, valid_losses, train_accuracies, valid_accuracies = train.calculateLossesAndAccuracies(model, train_loader, valid_loader, optimizer, criterion, 2)
        train.plot_loss(train_losses, valid_losses, train_accuracies, valid_accuracies)

        # Model
        model = GRUClassifierVar(len(self.vocab), self.vocab, len(self.label_encoder.classes_))
        criterion = nn.CrossEntropyLoss()
        optimizer = optim.AdamW(model.parameters(), lr=1e-3)
        train = TrainAndEvaluate(model, train_loader, test_loader, optimizer, criterion, 1)
        train.train_model(model, train_loader, optimizer, criterion)
        train.evaluate_model(model, valid_loader, criterion)
        train_losses, valid_losses, train_accuracies, valid_accuracies = train.calculateLossesAndAccuracies(model, train_loader, valid_loader, optimizer, criterion, 2)
        train.plot_loss(train_losses, valid_losses, train_accuracies, valid_accuracies)
        
if __name__ == "__main__":
    main = Main()
    main.run()