import torch
from torchtext.data.utils import get_tokenizer

# Dataset class
class TextDataset():
    def __init__(self, dataframe, vocab, label_encoder):
        self.texts = dataframe['text'].tolist()
        self.labels = torch.tensor(dataframe['label'].tolist())
        self.vocab = vocab
        self.tokenizer = get_tokenizer('basic_english')

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, index):
        text = self.texts[index]
        tokens = self.tokenizer(text)
        token_ids = [self.vocab[token] for token in tokens]
        return torch.tensor(token_ids, dtype=torch.long), self.labels[index]