from collections import Counter
from torchtext.vocab import build_vocab_from_iterator
from torchtext.data.utils import get_tokenizer
import pandas as pd
import torch
from torch.utils.data import DataLoader, Dataset
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence, pad_sequence
import torch.nn as nn
import torch.optim as optim
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import matplotlib.pyplot as plt

class TrainAndEvaluate:
    def __init__(self, model, train_loader, test_loader, optimizer, criterion, epochs):
        self.model = model
        self.train_loader = train_loader
        self.test_loader = test_loader
        self.optimizer = optimizer
        self.criterion = criterion
        self.epochs = epochs
    
    # Training function
    def train_model(self, model, train_loader, optimizer, criterion):
        model.train()
        epoch_loss = 0
        correct = 0
        total = 0
        if torch.cuda.is_available():
            print('CUDA is available! Using GPU for training.')
            device = torch.device('cuda')
        else:
            print('CUDA is not available. Using CPU for training.')
            device = torch.device('cpu')
        model.to(device)
        
        for labels, text, text_lengths in train_loader:
            if text.size(0) == 0:  # Skip the batch if it's empty
                continue
            optimizer.zero_grad()
            text, labels = text.to(device), labels.to(device)
            outputs = model(text, text_lengths)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            epoch_loss += loss.item()
            _, predicted = torch.max(outputs, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

        accuracy = 100 * correct / total
        return epoch_loss / len(train_loader), accuracy

    # Evaluation function
    def evaluate_model(self, model, valid_loader, criterion):
        model.eval()
        epoch_loss = 0
        correct = 0
        total = 0

        with torch.no_grad():
            for labels, text, text_lengths in valid_loader:
                if text.size(0) == 0:  # Skip the batch if it's empty
                    continue
                text, labels = text.cuda(), labels.cuda()
                outputs = model(text, text_lengths)
                loss = criterion(outputs, labels)

                epoch_loss += loss.item()
                _, predicted = torch.max(outputs, 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()

        accuracy = 100 * correct / total
        return epoch_loss / len(valid_loader), accuracy

    def calculateLossesAndAccuracies(self, model, train_loader, valid_loader, optimizer, criterion, num_epochs):
        train_losses, valid_losses = [], []
        train_accuracies, valid_accuracies = [], []
        early_stop_count = 0
        min_valid_loss = float('inf')

        for epoch in range(num_epochs):
            train_loss, train_acc = self.train_model(model, train_loader, optimizer, criterion)
            valid_loss, valid_acc = self.evaluate_model(model, valid_loader, criterion)

            train_losses.append(train_loss)
            valid_losses.append(valid_loss)
            train_accuracies.append(train_acc)
            valid_accuracies.append(valid_acc)

            # Early stopping check
            if valid_loss < min_valid_loss:
                min_valid_loss = valid_loss
                early_stop_count = 0  # reset count
            else:
                early_stop_count += 1

            if early_stop_count > 5:  # If validation loss doesn't improve for 5 consecutive epochs, stop
                print("Stopping early due to increasing validation loss.")
                break

            if epoch % 2 == 0 or epoch == num_epochs - 1:
                print(f'Epoch {epoch+1}/{num_epochs}')
                print(f'Train Loss: {train_loss:.3f} | Train Acc: {train_acc:.2f}%')
                print(f'Valid Loss: {valid_loss:.3f} | Valid Acc: {valid_acc:.2f}%')

        # Print final training and validation loss and accuracy
        print(f'Final Training Loss: {train_losses[-1]:.3f} | Final Training Acc: {train_accuracies[-1]:.2f}%')
        print(f'Final Validation Loss: {valid_losses[-1]:.3f} | Final Validation Acc: {valid_accuracies[-1]:.2f}%')
        return train_losses, valid_losses, train_accuracies, valid_accuracies


    def plot(train_losses, valid_losses, train_accuracies, valid_accuracies):
        plt.figure(figsize=(10, 5))
        plt.title("Training and Validation Loss")
        plt.plot(train_losses, label="Train Loss")
        plt.plot(valid_losses, label="Valid Loss")
        plt.xlabel("Epoch")
        plt.ylabel("Loss")
        plt.legend()
        plt.show()

        # Plot training and validation accuracy
        plt.figure(figsize=(10, 5))
        plt.title("Training and Validation Accuracy")
        plt.plot(train_accuracies, label="Train Accuracy")
        plt.plot(valid_accuracies, label="Valid Accuracy")
        plt.xlabel("Epoch")
        plt.ylabel("Accuracy")
        plt.legend()
        plt.show()
