import torch
import numpy as np

class EmbeddingMatrixCreator:
    def __init__(self, word_index, word2vec_model, embedding_dim=100):
        self.word_index = word_index
        self.word2vec_model = word2vec_model
        self.embedding_dim = embedding_dim

    def create_embedding_matrix(self):
        vocab_size = len(self.word_index) + 1
        embedding_matrix = torch.zeros(vocab_size, self.embedding_dim)
        for word, i in self.word_index.items():
            if word in self.word2vec_model.wv:
                embedding_matrix[i] = torch.tensor(self.word2vec_model.wv[word])
        return embedding_matrix
