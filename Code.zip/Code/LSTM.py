from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence, pad_sequence
import torch.nn as nn

class LSTMClassifier(nn.Module):
    def __init__(self, vocab_size, vocab, output_dim, embed_dim=100, hidden_dim=256, n_layers=2, dropout=0.5):
        super(LSTMClassifier, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=vocab['<pad>'])
        self.lstm = nn.LSTM(embed_dim, hidden_dim, num_layers=n_layers, batch_first=True, dropout=dropout)
        self.fc = nn.Linear(hidden_dim, output_dim)  # Adjusted for non-bidirectional
        self.dropout = nn.Dropout(dropout)

    def forward(self, text, text_lengths):
        text, text_lengths = text.cuda(), text_lengths.cuda()
        embedded = self.dropout(self.embedding(text))
        packed_embedded = pack_padded_sequence(embedded, text_lengths.cpu(), batch_first=True, enforce_sorted=False)
        packed_output, _ = self.lstm(packed_embedded)
        output, output_lengths = pad_packed_sequence(packed_output, batch_first=True)
        hidden = self.dropout(output[:, -1, :])  # Use the last hidden state
        return self.fc(hidden)
