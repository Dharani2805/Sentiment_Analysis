import torch
from torch.nn.utils.rnn import pad_sequence

class SequencePadder:
    def __init__(self, df):
        self.df = df

    def pad_sequences(self, sequences):
        sequences = [torch.tensor([ord(char) for char in text]) for text in self.df['text']]
        maxSequencesLength = int(self.df['text_length'].quantile(0.75)) + 20
        return pad_sequence(sequences, batch_first=True, padding_value=0)

