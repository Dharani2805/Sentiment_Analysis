import re

class TextCleaner:
    def __init__(self, df):
        self.df = df

    @staticmethod
    def clean_text(text):
        if isinstance(text, str):
            text = text.lower()
            text = re.sub(r'[^\w\s]', '', text)  # Remove punctuation
        else:
            text = ""  # Or some other placeholder for non-string values
        return text

    def clean_dataframe_columns(self, text_column, cleaned_text_column):
        self.df[cleaned_text_column] = self.df[text_column].apply(self.clean_text)
        return self.df